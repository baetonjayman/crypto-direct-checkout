<?php
// TEST ONLY: stands in for code an attacker slipped in. Does nothing.
